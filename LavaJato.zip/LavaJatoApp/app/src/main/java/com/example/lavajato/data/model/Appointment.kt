package com.example.lavajato.data.model

data class Appointment(
    val id: String,
    val date: String,
    val time: String,
    val serviceName: String,
    val vehicleModel: String,
    val status: String
)