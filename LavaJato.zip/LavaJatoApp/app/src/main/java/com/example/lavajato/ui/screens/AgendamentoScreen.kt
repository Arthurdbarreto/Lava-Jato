package com.example.lavajato.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lavajato.ui.components.AppButton
import com.example.lavajato.ui.components.AppTextField
import com.example.lavajato.ui.components.BottomNavigationBar
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.ScreenBackground
import com.example.lavajato.ui.theme.YellowAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendamentoScreen(
    onNavigateToHome: () -> Unit,
    onNavigateToMeusAgendamentos: () -> Unit
) {
    var vehicleModel by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Agendar Serviço",
                        color = YellowAccent,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NavyDark
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(
                currentRoute = "agendamento",
                onNavigateToHome = onNavigateToHome,
                onNavigateToAgendamento = {},
                onNavigateToMeusAgendamentos = onNavigateToMeusAgendamentos
            )
        },
        containerColor = ScreenBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Text(
                text = "Preencha os dados do agendamento",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )

            Spacer(modifier = Modifier.height(24.dp))

            AppTextField(
                value = vehicleModel,
                onValueChange = { vehicleModel = it },
                label = "Modelo do Veículo",
                leadingIcon = Icons.Default.DirectionsCar
            )

            Spacer(modifier = Modifier.height(16.dp))

            AppTextField(
                value = date,
                onValueChange = { date = it },
                label = "Data (DD/MM/AAAA)",
                leadingIcon = Icons.Default.CalendarToday
            )

            Spacer(modifier = Modifier.height(16.dp))

            AppTextField(
                value = time,
                onValueChange = { time = it },
                label = "Horário (HH:MM)",
                leadingIcon = Icons.Default.Schedule
            )

            Spacer(modifier = Modifier.height(32.dp))

            AppButton(
                text = "Confirmar Agendamento",
                onClick = onNavigateToMeusAgendamentos,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}