package com.example.lavajato.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.YellowAccent

@Composable
fun BottomNavigationBar(
    currentRoute: String,
    onNavigateToHome: () -> Unit,
    onNavigateToAgendamento: () -> Unit,
    onNavigateToMeusAgendamentos: () -> Unit
) {
    NavigationBar(
        containerColor = NavyDark
    ) {
        NavigationBarItem(
            selected = currentRoute == "home",
            onClick = onNavigateToHome,
            icon = { Icon(Icons.Default.Home, contentDescription = "Início") },
            label = { Text("Início") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDark,
                selectedTextColor = YellowAccent,
                indicatorColor = YellowAccent,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White
            )
        )
        NavigationBarItem(
            selected = currentRoute == "agendamento",
            onClick = onNavigateToAgendamento,
            icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "Agendar") },
            label = { Text("Agendar") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDark,
                selectedTextColor = YellowAccent,
                indicatorColor = YellowAccent,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White
            )
        )
        NavigationBarItem(
            selected = currentRoute == "meus_agendamentos",
            onClick = onNavigateToMeusAgendamentos,
            icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "Agendamentos") },
            label = { Text("Meus Agendamentos") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDark,
                selectedTextColor = YellowAccent,
                indicatorColor = YellowAccent,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White
            )
        )
    }
}