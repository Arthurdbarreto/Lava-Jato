package com.example.lavajato.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lavajato.data.model.Service
import com.example.lavajato.ui.theme.CardBackground
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.TextGraySecondary
import com.example.lavajato.ui.theme.YellowAccent

@Composable
fun ServiceCard(
    service: Service,
    onSelectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = service.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "R$ ${"%.2f".format(service.price)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = YellowAccent
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = service.description,
                fontSize = 14.sp,
                color = TextGraySecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Duração estimada: ${service.durationMinutes} min",
                fontSize = 12.sp,
                color = TextGraySecondary
            )
            Spacer(modifier = Modifier.height(12.dp))
            AppButton(
                text = "Selecionar",
                onClick = onSelectClick,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}