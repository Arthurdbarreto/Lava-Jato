package com.example.lavajato.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val ErrorRed = Color(0xFFB00020)

private val LightColorScheme = lightColorScheme(
    primary = YellowAccent,
    onPrimary = NavyDark,
    secondary = CardBackground,
    onSecondary = TextDarkPrimary,
    background = ScreenBackground,
    onBackground = TextDarkPrimary,
    surface = CardBackground,
    onSurface = TextDarkPrimary,
    error = ErrorRed
)

private val DarkColorScheme = darkColorScheme(
    primary = YellowAccent,
    onPrimary = NavyDark,
    secondary = CardBackground,
    onSecondary = TextDarkPrimary,
    background = ScreenBackground,
    onBackground = TextDarkPrimary,
    surface = CardBackground,
    onSurface = TextDarkPrimary,
    error = ErrorRed
)

@Composable
fun LavaJatoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}