package com.example.lavajato.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lavajato.data.model.Appointment
import com.example.lavajato.ui.theme.CardBackground
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.TextGraySecondary
import com.example.lavajato.ui.theme.YellowAccent

@Composable
fun AppointmentCard(
    appointment: Appointment,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = appointment.serviceName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Veículo: ${appointment.vehicleModel}",
                fontSize = 14.sp,
                color = TextGraySecondary
            )
            Text(
                text = "Data: ${appointment.date} às ${appointment.time}",
                fontSize = 14.sp,
                color = TextGraySecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Status: ${appointment.status}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = YellowAccent
            )
        }
    }
}