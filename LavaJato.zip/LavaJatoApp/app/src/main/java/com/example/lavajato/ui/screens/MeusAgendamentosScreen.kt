package com.example.lavajato.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.lavajato.data.model.Appointment
import com.example.lavajato.ui.components.AppointmentCard
import com.example.lavajato.ui.components.BottomNavigationBar
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.ScreenBackground
import com.example.lavajato.ui.theme.YellowAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeusAgendamentosScreen(
    onNavigateToHome: () -> Unit,
    onNavigateToAgendamento: () -> Unit
) {
    val sampleAppointments = listOf(
        Appointment(
            id = "1",
            date = "28/09/2026",
            time = "10:00",
            serviceName = "Lavagem Completa",
            vehicleModel = "Gol 1.0",
            status = "Confirmado"
        ),
        Appointment(
            id = "2",
            date = "15/09/2026",
            time = "14:30",
            serviceName = "Lavagem Simples",
            vehicleModel = "Civic",
            status = "Concluído"
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Meus Agendamentos",
                        color = YellowAccent,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NavyDark
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(
                currentRoute = "meus_agendamentos",
                onNavigateToHome = onNavigateToHome,
                onNavigateToAgendamento = onNavigateToAgendamento,
                onNavigateToMeusAgendamentos = {}
            )
        },
        containerColor = ScreenBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(sampleAppointments) { appointment ->
                AppointmentCard(appointment = appointment)
            }
        }
    }
}