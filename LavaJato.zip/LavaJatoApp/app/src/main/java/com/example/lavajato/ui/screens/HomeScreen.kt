package com.example.lavajato.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lavajato.data.model.Service
import com.example.lavajato.ui.components.BottomNavigationBar
import com.example.lavajato.ui.components.HomeShortcutCard
import com.example.lavajato.ui.components.ServiceCard
import com.example.lavajato.ui.theme.NavyDark
import com.example.lavajato.ui.theme.ScreenBackground
import com.example.lavajato.ui.theme.YellowAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToAgendamento: () -> Unit,
    onNavigateToMeusAgendamentos: () -> Unit
) {
    val sampleServices = listOf(
        Service("1", "Lavagem Simples", "Lavagem externa e aspiração básica", 40.0, 30),
        Service("2", "Lavagem Completa", "Lavagem externa, cera e higienização interna", 70.0, 60),
        Service("3", "Polimento Técnico", "Remoção de riscos e restauração do brilho", 150.0, 120)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Lava Jato Express",
                        color = YellowAccent,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NavyDark
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(
                currentRoute = "home",
                onNavigateToHome = {},
                onNavigateToAgendamento = onNavigateToAgendamento,
                onNavigateToMeusAgendamentos = onNavigateToMeusAgendamentos
            )
        },
        containerColor = ScreenBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Bem-vindo!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HomeShortcutCard(
                        title = "Novo Agendamento",
                        icon = Icons.Default.DirectionsCar,
                        onClick = onNavigateToAgendamento,
                        modifier = Modifier.weight(1f)
                    )
                    HomeShortcutCard(
                        title = "Meus Agendamentos",
                        icon = Icons.Default.CalendarMonth,
                        onClick = onNavigateToMeusAgendamentos,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Nossos Serviços",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
            }

            items(sampleServices) { service ->
                ServiceCard(
                    service = service,
                    onSelectClick = onNavigateToAgendamento
                )
            }
        }
    }
}