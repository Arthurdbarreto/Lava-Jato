package com.example.lavajato.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDark = Color(0xFF1E293B)
val YellowAccent = Color(0xFFF59E0B)
val ScreenBackground = Color(0xFFF8FAFC)
val CardBackground = Color(0xFFFFFFFF)
val TextDarkPrimary = Color(0xFF0F172A)
val TextGraySecondary = Color(0xFF64748B)
val BorderGray = Color(0xFFE2E8F0)