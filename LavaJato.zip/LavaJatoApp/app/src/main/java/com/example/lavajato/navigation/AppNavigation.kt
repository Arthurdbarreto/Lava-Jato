package com.example.lavajato.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.lavajato.ui.screens.AgendamentoScreen
import com.example.lavajato.ui.screens.CadastroScreen
import com.example.lavajato.ui.screens.HomeScreen
import com.example.lavajato.ui.screens.LoginScreen
import com.example.lavajato.ui.screens.MeusAgendamentosScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "login"
    ) {
        composable("login") {
            LoginScreen(
                onLoginClick = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onRegisterClick = {
                    navController.navigate("cadastro")
                }
            )
        }

        composable("cadastro") {
            CadastroScreen(
                onRegisterSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onLoginClick = {
                    navController.popBackStack()
                }
            )
        }

        composable("home") {
            HomeScreen(
                onNavigateToAgendamento = {
                    navController.navigate("agendamento")
                },
                onNavigateToMeusAgendamentos = {
                    navController.navigate("meus_agendamentos")
                }
            )
        }

        composable("agendamento") {
            AgendamentoScreen(
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                },
                onNavigateToMeusAgendamentos = {
                    navController.navigate("meus_agendamentos")
                }
            )
        }

        composable("meus_agendamentos") {
            MeusAgendamentosScreen(
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                },
                onNavigateToAgendamento = {
                    navController.navigate("agendamento")
                }
            )
        }
    }
}